
public interface contacts {

	public boolean contact(Object e);
}
